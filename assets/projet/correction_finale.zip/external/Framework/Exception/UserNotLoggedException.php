<?php

namespace Framework\Exception;

use Exception;

class UserNotLoggedException extends Exception
{

}