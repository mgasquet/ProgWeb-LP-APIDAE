<?php

namespace Framework\Exception;

use Exception;

class UserAlreadyLoggedException extends Exception
{

}