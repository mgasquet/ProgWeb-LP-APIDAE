<?php

namespace TheFeed;

use Framework\AppInitializer;

class TheFeed extends AppInitializer
{

}