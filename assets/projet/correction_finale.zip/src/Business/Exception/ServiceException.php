<?php

namespace TheFeed\Business\Exception;

use Exception;

class ServiceException extends Exception
{

}